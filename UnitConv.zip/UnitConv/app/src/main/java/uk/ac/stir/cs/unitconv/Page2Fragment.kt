package uk.ac.stir.cs.unitconv

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import kotlinx.android.synthetic.main.page2_fragment.*
import java.lang.Exception
import java.text.DecimalFormat

/**
 * This class contains the fragment that holds the conversion calculator, this is where
 * the user can enter the number that they want to convert.
 */
class Page2Fragment : Fragment() {

    private var unitValue: String = ""
    private var conversionValue: String = ""

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.page2_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val fragmentViewModel = ViewModelProviders.of(activity!!).get(FragmentViewModel::class.java)
        val dataBase = UnitDataBase(context!!)
        var conversionData: ConversionData = ConversionData()

        // The fragmentVIewModel allows communication between the two fragments, allows data to be passed through
        // The observe is used as a listener for the data that been sent from other fragments, this is sent when the user
        // selects the values they want to convert to and from
        fragmentViewModel.conversion.observe(this, Observer<Any> { conversion ->
            conversionData = conversion as ConversionData

            // Sets the text views to the values that have been selected
            selectedValueDisplayTextView.text = conversionData.convertFrom
            selectedConversionDisplayTextView.text = conversionData.convertTo

            // Sets the values to the the values that have been selected
            unitValue = conversionData.convertFrom
            conversionValue = conversionData.convertTo
        })

        /**
         * Initialises all required text edits and buttons used in the application.
         */
        val calculationInput = view.findViewById(R.id.calculationInputTextView) as EditText
        val calculationResult = view.findViewById(R.id.calculationResultTextView) as EditText

        val calculatorButtonNumber0 = view.findViewById(R.id.calculatorButtonNumber0) as Button
        val calculatorButtonNumber1 = view.findViewById(R.id.calculatorButtonNumber1) as Button
        val calculatorButtonNumber2 = view.findViewById(R.id.calculatorButtonNumber2) as Button
        val calculatorButtonNumber3 = view.findViewById(R.id.calculatorButtonNumber3) as Button
        val calculatorButtonNumber4 = view.findViewById(R.id.calculatorButtonNumber4) as Button
        val calculatorButtonNumber5 = view.findViewById(R.id.calculatorButtonNumber5) as Button
        val calculatorButtonNumber6 = view.findViewById(R.id.calculatorButtonNumber6) as Button
        val calculatorButtonNumber7 = view.findViewById(R.id.calculatorButtonNumber7) as Button
        val calculatorButtonNumber8 = view.findViewById(R.id.calculatorButtonNumber8) as Button
        val calculatorButtonNumber9 = view.findViewById(R.id.calculatorButtonNumber9) as Button
        val calculatorButtonDot = view.findViewById(R.id.calculatorButtonDot) as Button

        val calculatorButtonClear = view.findViewById(R.id.calculatorButtonClear) as Button
        val calculatorButtonEnter = view.findViewById(R.id.calculatorButtonEnter) as Button

        /**
         * Sets the inputted values into the calculationInput text area.
         */
        fun setValue(value: Int) {
            calculationInput.setText(
                StringBuilder().append(calculationInput.text.toString()).append(value).toString()
            )
        }

        /**
         * Clears the input from the calculationsInput text area and the results from the calculationResult area.
         */
        fun clearValues() {
            calculationInput.text = null
            calculationResult.text = null
        }

        /**
         * Converts the calculation result into text and formats it correctly to be displayed.
         */
        fun inputConversion() {
            // Gets the conversion rate from the database using the two values selected and stores the returned value into conversionRate
            val conversionRate: Double =
                dataBase.conversionRate(dataBase.readableDatabase, unitValue, conversionValue)
            // Sets the format for decimal values
            val valueFormat = DecimalFormat("#,###.#######")

            // Try catch used to ensure that input has been entered into the calculation field so the application does not crash when no value has been entered
            try {
                // Sets the calculation result as text along with the value name to be displayed in the calculation result field
                calculationResult.setText(
                    java.lang.StringBuilder().append(
                        valueFormat.format(
                            conversionRate.times(
                                calculationInput.text.toString().toDouble()
                            )
                        )
                    ).append(" $conversionValue")
                )
                // Catches any exception that are thrown
            } catch (e: Exception) {
                // Message displayed to the screen is there is no input enetered
                Toast.makeText(context, "Input is Required", Toast.LENGTH_SHORT).show()
            }
        }

        // Sets the commands for all the button included in the calculator,
        // sets each numbered button along with enter and clear processes
        calculatorButtonNumber0.setOnClickListener {
            setValue(0)
            calculatorButtonEnter.performClick()
        }

        calculatorButtonNumber1.setOnClickListener {
            setValue(1)
            calculatorButtonEnter.performClick()
        }

        calculatorButtonNumber2.setOnClickListener {
            setValue(2)
            calculatorButtonEnter.performClick()
        }

        calculatorButtonNumber3.setOnClickListener {
            setValue(3)
            calculatorButtonEnter.performClick()
        }

        calculatorButtonNumber4.setOnClickListener {
            setValue(4)
            calculatorButtonEnter.performClick()
        }

        calculatorButtonNumber5.setOnClickListener {
            setValue(5)
            calculatorButtonEnter.performClick()
        }

        calculatorButtonNumber6.setOnClickListener {
            setValue(6)
            calculatorButtonEnter.performClick()
        }

        calculatorButtonNumber7.setOnClickListener {
            setValue(7)
            calculatorButtonEnter.performClick()
        }

        calculatorButtonNumber8.setOnClickListener {
            setValue(8)
            calculatorButtonEnter.performClick()
        }

        calculatorButtonNumber9.setOnClickListener {
            setValue(9)
            calculatorButtonEnter.performClick()
        }

        // Couldn't get this to work correctly so not fully implemented
        calculatorButtonDot.setOnClickListener {

        }

        calculatorButtonEnter.setOnClickListener {
            inputConversion()
        }

        calculatorButtonClear.setOnClickListener {
            clearValues()
        }
    }
}