package uk.ac.stir.cs.unitconv

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

/**
 * This class is used to create connections to be used between the two page fragments,
 * this allows data to be passed on when selected from the spinner.
 */
class FragmentViewModel : ViewModel() {
    val conversion: MutableLiveData<ConversionData> by lazy {
        MutableLiveData<ConversionData>()
    }
}