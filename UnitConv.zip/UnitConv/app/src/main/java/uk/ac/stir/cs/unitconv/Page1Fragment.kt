package uk.ac.stir.cs.unitconv

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders

/**
 * This class holds the fragment that controls the spinners that uses the data stored in
 * the database.
 * Here the user can select the unit and conversion values that they want to use when they
 * get passed into other fragments in the application.
 */
class Page1Fragment : Fragment() {
    private var unitValue: String = ""
    private var convertFromValue: String = ""
    private var unitCache: Int = 0
    private var valueCache: Int = 0
    private var conversionCache: Int = 0

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.page1_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val fragmentViewModel = ViewModelProviders.of(activity!!).get(FragmentViewModel::class.java)
        var dataBase = UnitDataBase(context!!)

        // Declaring and initialising the spinners by matching them up with the spinners from the xml files
        val unitSpinner = view.findViewById(R.id.unitSpinner) as Spinner
        val valueSpinner = view.findViewById(R.id.valueSpinner) as Spinner
        val conversionSpinner = view.findViewById(R.id.conversionSpinner) as Spinner

        // The units array is created as an array adapter with the layouts of simple spinner items and drop downs
        var unitsArray: ArrayAdapter<String> =
            ArrayAdapter(context, android.R.layout.simple_spinner_item)
        unitsArray.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        // The value array is created as an array adapter with the layouts of simple spinner items and drop downs
        var valueArray: ArrayAdapter<String> =
            ArrayAdapter(context, android.R.layout.simple_spinner_item)
        valueArray.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        // The conversion array is created as an array adapter with the layouts of simple spinner items and drop downs
        var conversionArray: ArrayAdapter<String> =
            ArrayAdapter(context, android.R.layout.simple_spinner_item)
        conversionArray.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        // Sets the spinners with there relevant arrays
        unitSpinner.adapter = unitsArray
        valueSpinner.adapter = valueArray
        conversionSpinner.adapter = conversionArray

        // Method calls the update all the arrays by passing them in
        updateAllArrays(dataBase, unitsArray, valueArray, conversionArray, fragmentViewModel)

        // Method calls to carryout the actions for the unit spinner using the the database, the view model and all the spinners
        unitSpinnerActions(unitSpinner, dataBase, unitsArray, valueArray, conversionArray, fragmentViewModel)

        // Method calls to carryout the actions for the value spinner using the the database, the view model and all the spinners
        valueSpinnerActions(valueSpinner, dataBase, unitsArray, valueArray, conversionArray, fragmentViewModel)

        // Method calls to carryout the actions for the conversion spinner using the the database, the view model and all the spinners
        conversionSpinnerActions(conversionSpinner, dataBase, unitsArray, valueArray, conversionArray, fragmentViewModel)
    }

    /**
     * Contains the actions for the unit spinner when a selection has been made, sets the selection
     * and updates the units cache.
     *
     * @param unitSpinner Passes in the spinner that will be used
     * @param dataBase The instance of the database that will be used
     * @param valueArray The instance of the value array that will be used
     * @param conversionArray The instance of the conversion array that will be used
     * @param fragmentViewModel The instance of the view model that will be used
     */
    private fun unitSpinnerActions(unitSpinner: Spinner, dataBase: UnitDataBase, unitsArray: ArrayAdapter<String>, valueArray: ArrayAdapter<String>, conversionArray: ArrayAdapter<String>, fragmentViewModel: FragmentViewModel) {
        unitSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                // Stores the position of the value that has been selected in the spinner as the units cache
                // This makes sure that the spinner and displays the same when a changed has been made with the application
                unitCache = position
                // Method call ensures the all the arrays in the fragment are always up to date when changes are made
                updateAllArrays(dataBase, unitsArray, valueArray, conversionArray, fragmentViewModel)
                // Sets the value that is stored in the cache into the spinner display
                unitSpinner.setSelection(unitCache)
            }
        }
    }

    /**
     * Contains the actions for the value spinner when a selection has been made, sets the selection
     * and updates the value cache.
     *
     * @param valueSpinner Passes in the spinner that will be used
     * @param dataBase The instance of the database that will be used
     * @param valueArray The instance of the value array that will be used
     * @param conversionArray The instance of the conversion array that will be used
     * @param fragmentViewModel The instance of the view model that will be used
     */
    private fun valueSpinnerActions(valueSpinner: Spinner, dataBase: UnitDataBase, unitsArray: ArrayAdapter<String>, valueArray: ArrayAdapter<String>, conversionArray: ArrayAdapter<String>, fragmentViewModel: FragmentViewModel) {
        valueSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                // Stores the position of the value that has been selected in the spinner as the value cache
                // This makes sure that the spinner and displays the same when a changed has been made with the application
                valueCache = position
                // Method call ensures the all the arrays in the fragment are always up to date when changes are made
                updateAllArrays(dataBase, unitsArray, valueArray, conversionArray, fragmentViewModel)
                // Sets the value that is stored in the cache into the spinner display
                valueSpinner.setSelection(valueCache)
            }
        }
    }

    /**
     * Contains the actions for the conversion spinner when a selection has been made, sets the selection
     * and updates the conversion cache.
     *
     * @param conversionSpinner Passes in the spinner that will be used
     * @param dataBase The instance of the database that will be used
     * @param valueArray The instance of the value array that will be used
     * @param conversionArray The instance of the conversion array that will be used
     * @param fragmentViewModel The instance of the view model that will be used
     */
    private fun conversionSpinnerActions(conversionSpinner: Spinner, dataBase: UnitDataBase, unitsArray: ArrayAdapter<String>, valueArray: ArrayAdapter<String>, conversionArray: ArrayAdapter<String>, fragmentViewModel: FragmentViewModel) {
        conversionSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                // Stores the position of the value that has been selected in the spinner as the conversion cache
                // This makes sure that the spinner and displays the same when a changed has been made with the application
                conversionCache = position
                // Method call ensures the all the arrays in the fragment are always up to date when changes are made
                updateAllArrays(dataBase, unitsArray, valueArray, conversionArray, fragmentViewModel)
                // Sets the value that is stored in the cache into the spinner display
                conversionSpinner.setSelection(conversionCache)
            }
        }
    }

    /**
     * Updates all the arrays to ensure all the data the is being held within the spinners are the most up to date.
     * It also updates the values for the other fragments for the values that haven been selected.
     *
     * @param dataBase The instance of the database that will be used
     * @param valueArray The instance of the value array that will be used
     * @param conversionArray The instance of the conversion array that will be used
     * @param fragmentViewModel The instance of the view model that will be used
     */
    private fun updateAllArrays(dataBase: UnitDataBase, unitsArray: ArrayAdapter<String>, valueArray: ArrayAdapter<String>, conversionArray: ArrayAdapter<String>, fragmentViewModel: FragmentViewModel) {
        // Method called to clear the arrays each time to enable them to be the most up to date
        clearArrays(unitsArray, valueArray, conversionArray)

        // Method called to update the the value that has been selected and returns a value list which gets stored in the spinnerList
        var spinnerList = updateUnitValue(dataBase)
        // For statement used to go through the spinnerList and adds each value into the unitsArray
        for (i in spinnerList) {
            unitsArray.add(i)
        }

        // Method called to update the the value that has been selected and returns a conversion list which gets stored in the spinnerList
        spinnerList = updateConversionValue(dataBase)
        // For statement used to go through the spinnerList and adds each value in the unitsArray
        for (i in spinnerList) {
            valueArray.add(i)
        }

        // Method call to get the display of the unitValue and the convertFromValue, this gets stored in the conversionList
        var conversionList = dataBase.displayData(unitValue + convertFromValue)

        // If statement used to check if the conversions cache value if greater than the conversions list size
        // If this is true, the conversions cache value gets set to 0
        if (conversionCache > conversionList.size) {
            conversionCache = 0
        }

        // For statement used to go through the conversionList and adds each value into the conversionArray
        for (i in conversionList) {
            conversionArray.add(i.convertTo)
        }

        // Method calls for notifying the database that changes have been made to each array
        unitsArray.notifyDataSetChanged()
        valueArray.notifyDataSetChanged()
        conversionArray.notifyDataSetChanged()

        // The fragmentViewModel is used to communicate to other fragments, this allows the other
        // fragments use the values that have been selected from this fragment 
        // The conversion values will be able to be used for displaying in the other fragments
        fragmentViewModel.conversion.value = conversionList[conversionCache]
    }

    /**
     * Clears all of the arrays.
     *
     * @param unitsArray the reference being passed in for the unit array
     * @param valueArray the reference being passed in for the value array
     * @param conversionArray the reference being passed in for the conversion array
     */
    private fun clearArrays(unitsArray: ArrayAdapter<String>, valueArray: ArrayAdapter<String>, conversionArray: ArrayAdapter<String>) {
        unitsArray.clear()
        valueArray.clear()
        conversionArray.clear()
    }

    /**
     * Updates the unit values that has been selected along with the cache value.
     * Sets the unitValue to the value in the database to be displayed in the spinner.
     *
     * @param dataBase The instance of the database that will be used
     *
     * @return valueList Returns a mutable list of the value
     */
    private fun updateUnitValue(dataBase: UnitDataBase): MutableList<String> {
        var valueList = dataBase.spinnerInfo(" GROUP BY category", "category")

        // If statement used to check if the value list is currently empty
        if (valueList.isNotEmpty()) {
            // If statement used to check if the current value cache is greater than the value lists size
            if (valueCache > valueList.size) {
                // If the value cache is greater than the list size the cache value is set to 0
                valueCache = 0
            }
            // If the list is empty, the unitValue is set to value in the database using the unit cache to find the required value
            unitValue = " WHERE category = \'" + valueList[unitCache] + "\'"
        } else {
            // Else statement used to set the unitValue to nothing if the value list is not empty
            unitValue = ""
        }

        // Returns the valueList which will contain the value selected by the user
        return valueList
    }

    /**
     * Updates the conversion values that has been selected along with the conversion value.
     * Sets the conversionValue to the value in the database to be displayed in the spinner.
     *
     * @param dataBase The instance of the database that will be used
     *
     * @return conversionList Returns a mutable list of the value
     */
    private fun updateConversionValue(dataBase: UnitDataBase): MutableList<String> {
        var conversionList = dataBase.spinnerInfo("$unitValue GROUP by convertFrom", "convertFrom")

        // If statement used to check if the conversion list is currently empty
        if (conversionList.isNotEmpty()) {
            // If statement used to check if the current conversion cache is greater than the conversion lists size
            if (conversionCache > conversionList.size) {
                // If the value cache is greater than the list size the cache value is set to 0
                conversionCache = 0
            }
            // If the list is empty, the convertFromValue is set to value in the database using the conversion value cache to find the required conversion
            convertFromValue = " convertFrom = \'" + conversionList[valueCache] + "\'"

            // If statement used and stored in convertFromValue to check is the unitValue is not empty
            convertFromValue = if (unitValue.isNotEmpty()) {
                // If unit value is not empty the AND query is added to the convertFromValue
                " AND$convertFromValue"
            } else {
                // Else if the unit value is empty the WHERE query is added to the convertFromValue
                " WHERE$convertFromValue"
            }
            // Else statement used to set the convertFromValue to nothings if the value list is not empty
        } else {
            convertFromValue = ""
        }

        // Returns the conversionList which will contain the conversion selected by the user
        return conversionList
    }
}