package uk.ac.stir.cs.unitconv

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast

// Declaration and initialising of database values
const val DATABASE_NAME = "conversionDataBase"
const val TABLE_NAME = "conversionInfo"
const val COLUMN_ID = "id"
const val COLUMN_CATEGORY = "category"
const val COLUMN_CONVERT_FROM = "convertFrom"
const val COLUMN_MULTIPLIER = "multiplier"
const val COLUMN_CONVERT_TO = "convertTo"

/**
 * The database class is used to hold all of the data required for the functionality of the application.
 * Enables the user to input and remove conversions for them to then use.
 *
 * @param context Passes in the applications environment
 */
class UnitDataBase(private var context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, 1) {
    override fun onCreate(dataBase: SQLiteDatabase?) {
        val createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_CATEGORY + " VARCHAR(256)," +
                COLUMN_CONVERT_FROM + " VARCHAR(256)," +
                COLUMN_MULTIPLIER + " FLOAT," +
                COLUMN_CONVERT_TO + " VARCHAR(256))"
        dataBase?.execSQL(createTable)
    }

    /**
     * Updates the database by dropping the old table and creates a new table.
     *
     * @param dataBase The instance of the database that will be used
     * @param oldVersion Passes in the current version of the database
     * @param newVersion Passes in the new version of the database
     */
    override fun onUpgrade(dataBase: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        dataBase.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        // Calls the onCreate method to make the new version of the database
        onCreate(dataBase)
    }

    /**
     * This method controls how data gets inserted into the database, it ensures that all
     * the data getting passed in is valid.
     * Inserted data can be used to carryout conversions.
     *
     * @param conversionData The instance of the ConversionData class that will be used
     */
    fun insertData(conversionData: ConversionData) {
        // Declaring and initialising the variable that will store the value into the database
        var contentValues = ContentValues()

        val dataBase = this.writableDatabase

        // Stores all the values stored in the conversionData variables in the contentVales
        contentValues.put(COLUMN_CATEGORY, conversionData.category)
        contentValues.put(COLUMN_CONVERT_FROM, conversionData.convertFrom)
        contentValues.put(COLUMN_MULTIPLIER, conversionData.multiplier)
        contentValues.put(COLUMN_CONVERT_TO, conversionData.convertTo)

        // Creates an insert statement that adds the new created conversion into the database
        var input = dataBase.insert(TABLE_NAME, null, contentValues)

        // If statement used to check if the input is valid and can be inserted into the database
        if (input == (-1).toLong()) {
            // Displays a message to screen if the data was not inserted into the database
            Toast.makeText(context, "Failed to Insert", Toast.LENGTH_SHORT).show()
        } else {
            // Displays message to the screen if the data was inserted into the database
            Toast.makeText(context, "Successfully Inserted", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Reads the data that is currently being stored in the database, allows
     * the user to display the data stored with the use of a parameter if required.
     *
     * @param entry Passes in any required parameters for the query search
     *
     * @return conversionDataList Holds the data retrieved from the database
     */
    fun displayData(entry: String): MutableList<ConversionData> {
        // Mutable List uad as a generic ordered collection of elements that supports adding and removing elements
        var conversionDataList: MutableList<ConversionData> = ArrayList()

        val dataBase = this.readableDatabase
        // Query created to query and search the database
        val query = "Select * from $TABLE_NAME$entry"
        // The database getting queried using the value stored in query and then stored into the output variable
        val output = dataBase.rawQuery(query, null)

        // If statement used to ensure that the data stored in output is moved to the first position
        if (output.moveToFirst()) {
            // Do while statement used to ensure all data gets collected and stored
            do {
                var conversionData = ConversionData()

                // The conversionData holds the data held in each index column in the database by using their column names
                conversionData.id = output.getString(output.getColumnIndex(COLUMN_ID)).toInt()
                conversionData.category = output.getString(output.getColumnIndex(COLUMN_CATEGORY))
                conversionData.convertFrom =
                    output.getString(output.getColumnIndex(COLUMN_CONVERT_FROM))
                conversionData.multiplier =
                    output.getString(output.getColumnIndex(COLUMN_MULTIPLIER)).toDouble()
                conversionData.convertTo =
                    output.getString(output.getColumnIndex(COLUMN_CONVERT_TO))

                // Adds all the data stored in conversionData into the conversionDataList
                conversionDataList.add(conversionData)
                // Ends the do while loops when the output has moved on the next output
                // End when all the data has been collected
            } while (output.moveToNext())
        }

        // Closes the query call for the database
        output.close()
        // Closes the connection to the database
        dataBase.close()

        // Returns the conversionDataList that contains all required data collected
        return conversionDataList
    }

    /**
     * Retrieves all required data for each spinners throughout the application.
     *
     * @param entry Passes in the query entry for the spinner
     * @param unit Passes in the unit to be used for the spinner
     */
    fun spinnerInfo(entry: String, unit: String): MutableList<String> {
        var infoList: MutableList<String> = ArrayList()

        val dataBase = this.readableDatabase
        // Query created to query and search the database
        val query = "Select * from $TABLE_NAME$entry"
        // The database getting queried using the value stored in query and then stored into the output variable
        val output = dataBase.rawQuery(query, null)

        // If statement used to ensure that the data stored in output is moved to the first position
        if (output.moveToFirst()) {
            // Do while statement used to ensure all data stored in the infoList gets added into the relevent spinner
            do {
                infoList.add(output.getString(output.getColumnIndex(unit)))
                // Ends the do while loops when all data has been added into the spinner
            } while (output.moveToNext())
        }

        // Closes the query call for the database
        output.close()
        // Closes the connection to the database
        dataBase.close()

        // Returns the infoList that contains all the required data for the spinner
        return infoList
    }


    /**
     * Deletes data from the data base and resets the
     * autoincrement id for the next insert.
     *
     * @param id Passes in the id value requested to be deleted from the database
     */
    fun deleteData(id: Int) {
        val dataBase = this.writableDatabase

        // Deletes requested id from the database
//        dataBase.execSQL("DELETE FROM " + "TABLE_NAME" + " WHERE " + COLUMN_ID + "=\"" + id + "\";")

        // Deletes the whole table
//        dataBase.execSQL("DELETE FROM " + TABLE_NAME)//delete data from table
        // Reset the autoincrement id
//        dataBase.execSQL("DELETE FROM sqlite_sequence WHERE NAME = \'" + TABLE_NAME + "\' ")

        // Closes the connection to the database
//        dataBase.close()
    }

    /**
     * Carries out the conversion rate between two different selected values.
     *
     * @param dataBase The instance of the database that will be used
     * @param value The value getting used to convert from
     * @param conversion The conversion value getting used to convert to
     *
     * @return conversionRate Returns the conversion rate between the two different values entered
     */
    fun conversionRate(dataBase: SQLiteDatabase, value: String, conversion: String): Double {
        var conversionRate = 0.0

        // Query created to query and search the database
        val query =
            "SELECT $COLUMN_MULTIPLIER FROM $TABLE_NAME WHERE $COLUMN_CONVERT_FROM == '$value' AND $COLUMN_CONVERT_TO == '$conversion';"
        // The database getting queried using the value stored in query and then stored into the output variable
        val output = dataBase?.rawQuery(query, null)

        // If statement used to check that the output variable is not empty
        if (output != null) {
            // If statement used to ensure that the data stored in output is moved to the first position
            if (output.moveToFirst()) {
                // Gets the multiplier for the conversion between the two selected values and stores it in the conversionRate variable
                conversionRate = output.getDouble(output.getColumnIndex(COLUMN_MULTIPLIER))
            }
        }

        // Returns the conversion rate multiplier between the two selected values
        return conversionRate
    }

    /**
     * Inserts the default values into the data base, these vaules will always be
     * present in the database and cannot be deleted.
     */
    fun insertDefaultValues() {
        val dataBase = this.writableDatabase
        var contentValues = ContentValues()

        // Calls a method for each of the values held for the required database data.
        // Passes in and uses the contentValues and dataBase values to insert to the data into the database.
        // Method calls for the Currency units.
        conversionInfoGBP(dataBase, contentValues)
        conversionInfoUSD(dataBase, contentValues)
        conversionInfoEUR(dataBase, contentValues)
        conversionInfoJPY(dataBase, contentValues)

        // Method calls for the Measurement units.
        conversionInfoCentimeters(dataBase, contentValues)
        conversionInfoInches(dataBase, contentValues)
        conversionInfoMillimeters(dataBase, contentValues)
        conversionInfoFoot(dataBase, contentValues)

        // Method calls for the Weight units
        conversionInfoStone(dataBase, contentValues)
        conversionInfoPounds(dataBase, contentValues)
        conversionInfoGrams(dataBase, contentValues)
        conversionInfoKilograms(dataBase, contentValues)

        // Method calls for the Volume units
        conversionInfoLiters(dataBase, contentValues)
        conversionInfoMillilitres(dataBase, contentValues)
        conversionInfoPints(dataBase, contentValues)
        conversionInfoGallons(dataBase, contentValues)

        //Method calls for the Speed units
        conversionInfoMPH(dataBase, contentValues)
        conversionInfoKPH(dataBase, contentValues)
        conversionInfoKnot(dataBase, contentValues)
        conversionInfoMPS(dataBase, contentValues)
    }

    /**
     * Conversion data for converting GBP into other currencies.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoGBP(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for GBP to GBP
        contentValues.put(COLUMN_CATEGORY, "Currency")
        contentValues.put(COLUMN_CONVERT_FROM, "GBP")
        contentValues.put(COLUMN_CONVERT_TO, "GBP")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for GBP to USD
        contentValues.put(COLUMN_CATEGORY, "Currency")
        contentValues.put(COLUMN_CONVERT_FROM, "GBP")
        contentValues.put(COLUMN_CONVERT_TO, "USD")
        contentValues.put(COLUMN_MULTIPLIER, "1.33")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for GBP to EUR
        contentValues.put(COLUMN_CATEGORY, "Currency")
        contentValues.put(COLUMN_CONVERT_FROM, "GBP")
        contentValues.put(COLUMN_CONVERT_TO, "EUR")
        contentValues.put(COLUMN_MULTIPLIER, "1.11")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for GBP to JPY
        contentValues.put(COLUMN_CATEGORY, "Currency")
        contentValues.put(COLUMN_CONVERT_FROM, "GBP")
        contentValues.put(COLUMN_CONVERT_TO, "JPY")
        contentValues.put(COLUMN_MULTIPLIER, "138.48")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting USD into other currencies.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoUSD(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for USD to USD
        contentValues.put(COLUMN_CATEGORY, "Currency")
        contentValues.put(COLUMN_CONVERT_FROM, "USD")
        contentValues.put(COLUMN_CONVERT_TO, "USD")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for USD to GBP
        contentValues.put(COLUMN_CATEGORY, "Currency")
        contentValues.put(COLUMN_CONVERT_FROM, "USD")
        contentValues.put(COLUMN_CONVERT_TO, "GBP")
        contentValues.put(COLUMN_MULTIPLIER, "0.75")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for USD to EUR
        contentValues.put(COLUMN_CATEGORY, "Currency")
        contentValues.put(COLUMN_CONVERT_FROM, "USD")
        contentValues.put(COLUMN_CONVERT_TO, "EUR")
        contentValues.put(COLUMN_MULTIPLIER, "0.84")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for USD to JPY
        contentValues.put(COLUMN_CATEGORY, "Currency")
        contentValues.put(COLUMN_CONVERT_FROM, "USD")
        contentValues.put(COLUMN_CONVERT_TO, "JPY")
        contentValues.put(COLUMN_MULTIPLIER, "104.07")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting EUR into other currencies.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoEUR(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for EUR to EUR
        contentValues.put(COLUMN_CATEGORY, "Currency")
        contentValues.put(COLUMN_CONVERT_FROM, "EUR")
        contentValues.put(COLUMN_CONVERT_TO, "EUR")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for EUR to GBP
        contentValues.put(COLUMN_CATEGORY, "Currency")
        contentValues.put(COLUMN_CONVERT_FROM, "EUR")
        contentValues.put(COLUMN_CONVERT_TO, "GBP")
        contentValues.put(COLUMN_MULTIPLIER, "0.90")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for EUR to USD
        contentValues.put(COLUMN_CATEGORY, "Currency")
        contentValues.put(COLUMN_CONVERT_FROM, "EUR")
        contentValues.put(COLUMN_CONVERT_TO, "USD")
        contentValues.put(COLUMN_MULTIPLIER, "1.20")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for EUR to JPY
        contentValues.put(COLUMN_CATEGORY, "Currency")
        contentValues.put(COLUMN_CONVERT_FROM, "EUR")
        contentValues.put(COLUMN_CONVERT_TO, "JPY")
        contentValues.put(COLUMN_MULTIPLIER, "124.50")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting JPY into other currencies.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoJPY(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for JPY to JPY
        contentValues.put(COLUMN_CATEGORY, "Currency")
        contentValues.put(COLUMN_CONVERT_FROM, "JPY")
        contentValues.put(COLUMN_CONVERT_TO, "JPY")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for JPY to GBP
        contentValues.put(COLUMN_CATEGORY, "Currency")
        contentValues.put(COLUMN_CONVERT_FROM, "JPY")
        contentValues.put(COLUMN_CONVERT_TO, "GBP")
        contentValues.put(COLUMN_MULTIPLIER, "0.0072")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for JPY to USD
        contentValues.put(COLUMN_CATEGORY, "Currency")
        contentValues.put(COLUMN_CONVERT_FROM, "JPY")
        contentValues.put(COLUMN_CONVERT_TO, "USD")
        contentValues.put(COLUMN_MULTIPLIER, "0.0096")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for EUR to JPY
        contentValues.put(COLUMN_CATEGORY, "Currency")
        contentValues.put(COLUMN_CONVERT_FROM, "JPY")
        contentValues.put(COLUMN_CONVERT_TO, "EUR")
        contentValues.put(COLUMN_MULTIPLIER, "0.0080")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting Centimeters into other measurements.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoCentimeters(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for Centimeters to Centimeters
        contentValues.put(COLUMN_CATEGORY, "Measurements")
        contentValues.put(COLUMN_CONVERT_FROM, "Centimeters")
        contentValues.put(COLUMN_CONVERT_TO, "Centimeters")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Centimeters to Inches
        contentValues.put(COLUMN_CATEGORY, "Measurements")
        contentValues.put(COLUMN_CONVERT_FROM, "Centimeters")
        contentValues.put(COLUMN_CONVERT_TO, "Inches")
        contentValues.put(COLUMN_MULTIPLIER, "0.393701")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Centimeters to Millimeters
        contentValues.put(COLUMN_CATEGORY, "Measurements")
        contentValues.put(COLUMN_CONVERT_FROM, "Centimeters")
        contentValues.put(COLUMN_CONVERT_TO, "Millimeters")
        contentValues.put(COLUMN_MULTIPLIER, "10.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Centimeters to Foot
        contentValues.put(COLUMN_CATEGORY, "Measurements")
        contentValues.put(COLUMN_CONVERT_FROM, "Centimeters")
        contentValues.put(COLUMN_CONVERT_TO, "Foot")
        contentValues.put(COLUMN_MULTIPLIER, "0.0328084")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting Inches into other measurements.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoInches(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for Inches to Inches
        contentValues.put(COLUMN_CATEGORY, "Measurements")
        contentValues.put(COLUMN_CONVERT_FROM, "Inches")
        contentValues.put(COLUMN_CONVERT_TO, "Inches")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Inches to Centimeters
        contentValues.put(COLUMN_CATEGORY, "Measurements")
        contentValues.put(COLUMN_CONVERT_FROM, "Inches")
        contentValues.put(COLUMN_CONVERT_TO, "Centimeters")
        contentValues.put(COLUMN_MULTIPLIER, "2.54")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Inches to Millimeters
        contentValues.put(COLUMN_CATEGORY, "Measurements")
        contentValues.put(COLUMN_CONVERT_FROM, "Inches")
        contentValues.put(COLUMN_CONVERT_TO, "Millimeters")
        contentValues.put(COLUMN_MULTIPLIER, "25.40")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Inches to Foot
        contentValues.put(COLUMN_CATEGORY, "Measurements")
        contentValues.put(COLUMN_CONVERT_FROM, "Inches")
        contentValues.put(COLUMN_CONVERT_TO, "Foot")
        contentValues.put(COLUMN_MULTIPLIER, "0.0833333")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting Inches into other measurements.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoMillimeters(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for Millimeters to Millimeters
        contentValues.put(COLUMN_CATEGORY, "Measurements")
        contentValues.put(COLUMN_CONVERT_FROM, "Millimeters")
        contentValues.put(COLUMN_CONVERT_TO, "Millimeters")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Millimeters to Centimeters
        contentValues.put(COLUMN_CATEGORY, "Measurements")
        contentValues.put(COLUMN_CONVERT_FROM, "Millimeters")
        contentValues.put(COLUMN_CONVERT_TO, "Centimeters")
        contentValues.put(COLUMN_MULTIPLIER, "0.10")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Millimeters to Inches
        contentValues.put(COLUMN_CATEGORY, "Measurements")
        contentValues.put(COLUMN_CONVERT_FROM, "Millimeters")
        contentValues.put(COLUMN_CONVERT_TO, "Inches")
        contentValues.put(COLUMN_MULTIPLIER, "0.0393701")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Millimeters to Foot
        contentValues.put(COLUMN_CATEGORY, "Measurements")
        contentValues.put(COLUMN_CONVERT_FROM, "Millimeters")
        contentValues.put(COLUMN_CONVERT_TO, "Foot")
        contentValues.put(COLUMN_MULTIPLIER, "0.003280841666667")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting Foot into other measurements.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoFoot(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for Foot to Foot
        contentValues.put(COLUMN_CATEGORY, "Measurements")
        contentValues.put(COLUMN_CONVERT_FROM, "Foot")
        contentValues.put(COLUMN_CONVERT_TO, "Foot")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Foot to Centimeters
        contentValues.put(COLUMN_CATEGORY, "Measurements")
        contentValues.put(COLUMN_CONVERT_FROM, "Foot")
        contentValues.put(COLUMN_CONVERT_TO, "Centimeters")
        contentValues.put(COLUMN_MULTIPLIER, "30.48")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Foot to Inches
        contentValues.put(COLUMN_CATEGORY, "Measurements")
        contentValues.put(COLUMN_CONVERT_FROM, "Foot")
        contentValues.put(COLUMN_CONVERT_TO, "Inches")
        contentValues.put(COLUMN_MULTIPLIER, "12.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Foot to Millimeters
        contentValues.put(COLUMN_CATEGORY, "Measurements")
        contentValues.put(COLUMN_CONVERT_FROM, "Foot")
        contentValues.put(COLUMN_CONVERT_TO, "Millimeters")
        contentValues.put(COLUMN_MULTIPLIER, "304.80")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting Stone into other weights.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoStone(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for Stone to Stone
        contentValues.put(COLUMN_CATEGORY, "Weights")
        contentValues.put(COLUMN_CONVERT_FROM, "Stone")
        contentValues.put(COLUMN_CONVERT_TO, "Stone")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Stone to Pounds
        contentValues.put(COLUMN_CATEGORY, "Weights")
        contentValues.put(COLUMN_CONVERT_FROM, "Stone")
        contentValues.put(COLUMN_CONVERT_TO, "Pounds")
        contentValues.put(COLUMN_MULTIPLIER, "14.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Stone to Grams
        contentValues.put(COLUMN_CATEGORY, "Weights")
        contentValues.put(COLUMN_CONVERT_FROM, "Stone")
        contentValues.put(COLUMN_CONVERT_TO, "Grams")
        contentValues.put(COLUMN_MULTIPLIER, "6350.29")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Stone to Kilograms
        contentValues.put(COLUMN_CATEGORY, "Weights")
        contentValues.put(COLUMN_CONVERT_FROM, "Stone")
        contentValues.put(COLUMN_CONVERT_TO, "Kilograms")
        contentValues.put(COLUMN_MULTIPLIER, "6.35029")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting Pounds into other weights.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoPounds(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for Pounds to Pounds
        contentValues.put(COLUMN_CATEGORY, "Weights")
        contentValues.put(COLUMN_CONVERT_FROM, "Pounds")
        contentValues.put(COLUMN_CONVERT_TO, "Pounds")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Pounds to Stone
        contentValues.put(COLUMN_CATEGORY, "Weights")
        contentValues.put(COLUMN_CONVERT_FROM, "Pounds")
        contentValues.put(COLUMN_CONVERT_TO, "Stone")
        contentValues.put(COLUMN_MULTIPLIER, "0.0714286")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Pounds to Grams
        contentValues.put(COLUMN_CATEGORY, "Weights")
        contentValues.put(COLUMN_CONVERT_FROM, "Pounds")
        contentValues.put(COLUMN_CONVERT_TO, "Grams")
        contentValues.put(COLUMN_MULTIPLIER, "453.592")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Pounds to Kilograms
        contentValues.put(COLUMN_CATEGORY, "Weights")
        contentValues.put(COLUMN_CONVERT_FROM, "Pounds")
        contentValues.put(COLUMN_CONVERT_TO, "Kilograms")
        contentValues.put(COLUMN_MULTIPLIER, "0.453592")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting Grams into other weights.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoGrams(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for Grams to Grams
        contentValues.put(COLUMN_CATEGORY, "Weights")
        contentValues.put(COLUMN_CONVERT_FROM, "Grams")
        contentValues.put(COLUMN_CONVERT_TO, "Grams")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Grams to Stone
        contentValues.put(COLUMN_CATEGORY, "Weights")
        contentValues.put(COLUMN_CONVERT_FROM, "Grams")
        contentValues.put(COLUMN_CONVERT_TO, "Stone")
        contentValues.put(COLUMN_MULTIPLIER, "0.000157473")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Grams to Pounds
        contentValues.put(COLUMN_CATEGORY, "Weights")
        contentValues.put(COLUMN_CONVERT_FROM, "Grams")
        contentValues.put(COLUMN_CONVERT_TO, "Pounds")
        contentValues.put(COLUMN_MULTIPLIER, "0.00220462")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Grams to Kilograms
        contentValues.put(COLUMN_CATEGORY, "Weights")
        contentValues.put(COLUMN_CONVERT_FROM, "Grams")
        contentValues.put(COLUMN_CONVERT_TO, "Kilograms")
        contentValues.put(COLUMN_MULTIPLIER, "0.001")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting Kilograms into other weights.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoKilograms(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for KiloGrams to KiloGrams
        contentValues.put(COLUMN_CATEGORY, "Weights")
        contentValues.put(COLUMN_CONVERT_FROM, "KiloGrams")
        contentValues.put(COLUMN_CONVERT_TO, "KiloGrams")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for KiloGrams to Stone
        contentValues.put(COLUMN_CATEGORY, "Weights")
        contentValues.put(COLUMN_CONVERT_FROM, "KiloGrams")
        contentValues.put(COLUMN_CONVERT_TO, "Stone")
        contentValues.put(COLUMN_MULTIPLIER, "0.157473")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for KiloGrams to Pounds
        contentValues.put(COLUMN_CATEGORY, "Weights")
        contentValues.put(COLUMN_CONVERT_FROM, "KiloGrams")
        contentValues.put(COLUMN_CONVERT_TO, "Pounds")
        contentValues.put(COLUMN_MULTIPLIER, "2.20462")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for KiloGrams to Grams
        contentValues.put(COLUMN_CATEGORY, "Weights")
        contentValues.put(COLUMN_CONVERT_FROM, "KiloGrams")
        contentValues.put(COLUMN_CONVERT_TO, "Grams")
        contentValues.put(COLUMN_MULTIPLIER, "1000.00")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting Liters into other volumes.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoLiters(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for Liters to Liters
        contentValues.put(COLUMN_CATEGORY, "Volumes")
        contentValues.put(COLUMN_CONVERT_FROM, "Liters")
        contentValues.put(COLUMN_CONVERT_TO, "Liters")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Liters to Millilitres
        contentValues.put(COLUMN_CATEGORY, "Volumes")
        contentValues.put(COLUMN_CONVERT_FROM, "Liters")
        contentValues.put(COLUMN_CONVERT_TO, "Millilitres")
        contentValues.put(COLUMN_MULTIPLIER, "1000")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Liters to Pints
        contentValues.put(COLUMN_CATEGORY, "Volumes")
        contentValues.put(COLUMN_CONVERT_FROM, "Liters")
        contentValues.put(COLUMN_CONVERT_TO, "Pints")
        contentValues.put(COLUMN_MULTIPLIER, "1.75975")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Liters to Gallons
        contentValues.put(COLUMN_CATEGORY, "Volumes")
        contentValues.put(COLUMN_CONVERT_FROM, "Liters")
        contentValues.put(COLUMN_CONVERT_TO, "Gallons")
        contentValues.put(COLUMN_MULTIPLIER, "0.219969")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting Liters into other volumes.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoMillilitres(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for Millilitres to Millilitres
        contentValues.put(COLUMN_CATEGORY, "Volumes")
        contentValues.put(COLUMN_CONVERT_FROM, "Millilitres")
        contentValues.put(COLUMN_CONVERT_TO, "Millilitres")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Millilitres to Liters
        contentValues.put(COLUMN_CATEGORY, "Volumes")
        contentValues.put(COLUMN_CONVERT_FROM, "Millilitres")
        contentValues.put(COLUMN_CONVERT_TO, "Liters")
        contentValues.put(COLUMN_MULTIPLIER, "0.001")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Millilitres to Pints
        contentValues.put(COLUMN_CATEGORY, "Volumes")
        contentValues.put(COLUMN_CONVERT_FROM, "Millilitres")
        contentValues.put(COLUMN_CONVERT_TO, "Pints")
        contentValues.put(COLUMN_MULTIPLIER, "0.00211338")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Millilitres to Gallons
        contentValues.put(COLUMN_CATEGORY, "Volumes")
        contentValues.put(COLUMN_CONVERT_FROM, "Millilitres")
        contentValues.put(COLUMN_CONVERT_TO, "Gallons")
        contentValues.put(COLUMN_MULTIPLIER, "0.000219969")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting Pints into other volumes.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoPints(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for Pints to Pints
        contentValues.put(COLUMN_CATEGORY, "Volumes")
        contentValues.put(COLUMN_CONVERT_FROM, "Pints")
        contentValues.put(COLUMN_CONVERT_TO, "Pints")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Pints to Liters
        contentValues.put(COLUMN_CATEGORY, "Volumes")
        contentValues.put(COLUMN_CONVERT_FROM, "Pints")
        contentValues.put(COLUMN_CONVERT_TO, "Liters")
        contentValues.put(COLUMN_MULTIPLIER, "0.568261")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Pints to Millilitres
        contentValues.put(COLUMN_CATEGORY, "Volumes")
        contentValues.put(COLUMN_CONVERT_FROM, "Pints")
        contentValues.put(COLUMN_CONVERT_TO, "Millilitres")
        contentValues.put(COLUMN_MULTIPLIER, "568.261")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Pints to Gallons
        contentValues.put(COLUMN_CATEGORY, "Volumes")
        contentValues.put(COLUMN_CONVERT_FROM, "Pints")
        contentValues.put(COLUMN_CONVERT_TO, "Gallons")
        contentValues.put(COLUMN_MULTIPLIER, "0.125")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting Gallons into other volumes.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoGallons(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for Pints to Pints
        contentValues.put(COLUMN_CATEGORY, "Volumes")
        contentValues.put(COLUMN_CONVERT_FROM, "Gallons")
        contentValues.put(COLUMN_CONVERT_TO, "Gallons")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Gallons to Liters
        contentValues.put(COLUMN_CATEGORY, "Volumes")
        contentValues.put(COLUMN_CONVERT_FROM, "Gallons")
        contentValues.put(COLUMN_CONVERT_TO, "Liters")
        contentValues.put(COLUMN_MULTIPLIER, "4.54609")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Gallons to Millilitres
        contentValues.put(COLUMN_CATEGORY, "Volumes")
        contentValues.put(COLUMN_CONVERT_FROM, "Gallons")
        contentValues.put(COLUMN_CONVERT_TO, "Millilitres")
        contentValues.put(COLUMN_MULTIPLIER, "4546.09")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Gallons to Pints
        contentValues.put(COLUMN_CATEGORY, "Volumes")
        contentValues.put(COLUMN_CONVERT_FROM, "Gallons")
        contentValues.put(COLUMN_CONVERT_TO, "Pints")
        contentValues.put(COLUMN_MULTIPLIER, "8")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting MPH into other volumes.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoMPH(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for MPH to MPH
        contentValues.put(COLUMN_CATEGORY, "Speed")
        contentValues.put(COLUMN_CONVERT_FROM, "MPH")
        contentValues.put(COLUMN_CONVERT_TO, "MPH")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for MPH to KPH
        contentValues.put(COLUMN_CATEGORY, "Speed")
        contentValues.put(COLUMN_CONVERT_FROM, "MPH")
        contentValues.put(COLUMN_CONVERT_TO, "KPH")
        contentValues.put(COLUMN_MULTIPLIER, "3.6")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for MPH to Knot
        contentValues.put(COLUMN_CATEGORY, "Speed")
        contentValues.put(COLUMN_CONVERT_FROM, "MPH")
        contentValues.put(COLUMN_CONVERT_TO, "Knot")
        contentValues.put(COLUMN_MULTIPLIER, "1.94384")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for MPH to MPS
        contentValues.put(COLUMN_CATEGORY, "Speed")
        contentValues.put(COLUMN_CONVERT_FROM, "MPH")
        contentValues.put(COLUMN_CONVERT_TO, "MPS")
        contentValues.put(COLUMN_MULTIPLIER, "0.51444325460445")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting KPH into other volumes.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoKPH(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for KPH to KPH
        contentValues.put(COLUMN_CATEGORY, "Speed")
        contentValues.put(COLUMN_CONVERT_FROM, "KPH")
        contentValues.put(COLUMN_CONVERT_TO, "KPH")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for KPH to MPH
        contentValues.put(COLUMN_CATEGORY, "Speed")
        contentValues.put(COLUMN_CONVERT_FROM, "KPH")
        contentValues.put(COLUMN_CONVERT_TO, "MPH")
        contentValues.put(COLUMN_MULTIPLIER, "0.621371")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for KPH to Knot
        contentValues.put(COLUMN_CATEGORY, "Speed")
        contentValues.put(COLUMN_CONVERT_FROM, "KPH")
        contentValues.put(COLUMN_CONVERT_TO, "Knot")
        contentValues.put(COLUMN_MULTIPLIER, "0.539957")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for KPH to MPS
        contentValues.put(COLUMN_CATEGORY, "Speed")
        contentValues.put(COLUMN_CONVERT_FROM, "KPH")
        contentValues.put(COLUMN_CONVERT_TO, "MPS")
        contentValues.put(COLUMN_MULTIPLIER, "0.277778")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting Knot into other volumes.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoKnot(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for Knot to Knot
        contentValues.put(COLUMN_CATEGORY, "Speed")
        contentValues.put(COLUMN_CONVERT_FROM, "Knot")
        contentValues.put(COLUMN_CONVERT_TO, "Knot")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Knot to MPH
        contentValues.put(COLUMN_CATEGORY, "Speed")
        contentValues.put(COLUMN_CONVERT_FROM, "Knot")
        contentValues.put(COLUMN_CONVERT_TO, "MPH")
        contentValues.put(COLUMN_MULTIPLIER, "1.15078")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Knot to KPH
        contentValues.put(COLUMN_CATEGORY, "Speed")
        contentValues.put(COLUMN_CONVERT_FROM, "Knot")
        contentValues.put(COLUMN_CONVERT_TO, "KPH")
        contentValues.put(COLUMN_MULTIPLIER, "1.852")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for Knot to MPS
        contentValues.put(COLUMN_CATEGORY, "Speed")
        contentValues.put(COLUMN_CONVERT_FROM, "Knot")
        contentValues.put(COLUMN_CONVERT_TO, "MPS")
        contentValues.put(COLUMN_MULTIPLIER, "0.514444")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }

    /**
     * Conversion data for converting MPS into other volumes.
     *
     * @param dataBase the instance of the database that will be used
     * @param contentValues enables the data to be inserted into the database
     */
    private fun conversionInfoMPS(dataBase: SQLiteDatabase, contentValues: ContentValues) {
        // Conversion for MPS to MPS
        contentValues.put(COLUMN_CATEGORY, "Speed")
        contentValues.put(COLUMN_CONVERT_FROM, "MPS")
        contentValues.put(COLUMN_CONVERT_TO, "Knot")
        contentValues.put(COLUMN_MULTIPLIER, "1.00")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for MPS to MPH
        contentValues.put(COLUMN_CATEGORY, "Speed")
        contentValues.put(COLUMN_CONVERT_FROM, "MPS")
        contentValues.put(COLUMN_CONVERT_TO, "MPH")
        contentValues.put(COLUMN_MULTIPLIER, "2.23694")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for MPS to KPH
        contentValues.put(COLUMN_CATEGORY, "Speed")
        contentValues.put(COLUMN_CONVERT_FROM, "MPS")
        contentValues.put(COLUMN_CONVERT_TO, "KPH")
        contentValues.put(COLUMN_MULTIPLIER, "3.6")
        dataBase.insert(TABLE_NAME, null, contentValues)

        // Conversion for MPS to Knot
        contentValues.put(COLUMN_CATEGORY, "Speed")
        contentValues.put(COLUMN_CONVERT_FROM, "MPS")
        contentValues.put(COLUMN_CONVERT_TO, "Knot")
        contentValues.put(COLUMN_MULTIPLIER, "1.94384")
        dataBase.insert(TABLE_NAME, null, contentValues)
    }
}
