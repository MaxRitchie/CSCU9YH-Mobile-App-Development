package uk.ac.stir.cs.unitconv

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.page3_fragment.*

/**
 * This class contains the fragment that controls the ability to insert, display and
 * delete conversion values from the database.
 */
class Page3Fragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.page3_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val dataBase = UnitDataBase(context!!)

        // Method called to add the default data into the database
        addDefaultData(dataBase)
        // Method called for in the insertion of data in the database from the user
        insertData(dataBase)
        // Method called for displaying the data stored in the database
        displayData(dataBase)
        // Method called for deleting data from the database
        deleteData(dataBase)
    }

    /**
     * Adds the default data into the database, these values will always
     * be present in the database and cannot be deleted.
     *
     * @param dataBase The instance of the database that will be used
     */
    private fun addDefaultData(dataBase: UnitDataBase) {
        var displayData = dataBase.displayData("")

        // Checks to see if the default data is already inserted to prevent duplication.
        // If there is no data, the default data gets added.
        if (displayData.isEmpty()) {
            // Inserts default values that are always in the database
            dataBase.insertDefaultValues()
        }
    }

    /**
     * Enables the user to enter in their own values for a conversion and
     * insert it into the database to then be used throughout the application.
     *
     * @param dataBase The instance of the database that will be used
     */
    private fun insertData(dataBase: UnitDataBase) {
        var conversionData: ConversionData

        var unit: String
        var value: String
        var multiplier = 0.0
        var conversion: String

        // This button performs the action of inserting a new conversion into the database that the user has entered
        insertButton.setOnClickListener {
            // Converts the inputs from the texts fields into Strings and makes sure that the first character of the string is a capital
            // and the rest of the characters are lower case for the unit input. They then get stored into their relevant variable.
            unit = newUnitInputEditText.text.toString().toLowerCase().capitalize()
            value = newValueInputEditText.text.toString()
            conversion = newConversionInputEditText.text.toString()

            // If statement used to check is the multiplier input is empty
            if (newMultiplierInputEditText.text.toString().isNotEmpty()) {
                // Converts the input from the text fields into a double and stores the value into the multiplier variable
                multiplier = newMultiplierInputEditText.text.toString().toDouble()
            }

            // If statement used to validate the entered values
            // If valid, the data is inserted into the database
            // IF invalid, the relevant validation check is carried out
            if (validateInput(unit, value, multiplier, conversion)) {
                // Collects all the entered data into on variable
                conversionData = ConversionData(unit, value, multiplier, conversion)
                // Inserts the new data conversion into the database
                dataBase.insertData(conversionData)
                // Displays the database on the screen
                displayButton.performClick()
                // Calls the clear text method to clear the text fields
                clearText()
            }
        }
    }

    /**
     * Clears all the text fields that are displayed on the screen.
     */
    private fun clearText() {
        newUnitInputEditText.setText("")
        newValueInputEditText.setText("")
        newMultiplierInputEditText.setText("")
        newConversionInputEditText.setText("")
        deleteDatabaseValueNumberInput.setText("")
    }

    /**
     * Validation is carried out on the inputted values before it gets added into the database.
     *
     * @param unit Passes in the unit entered by the user
     * @param value Passes in the values entered by the user
     * @param multiplier Passes in the multiplier entered by the user
     * @param conversion Passes in the conversion entered by the user
     *
     * @return inputIsValid Returns either true or false
     */
    private fun validateInput(
        unit: String,
        value: String,
        multiplier: Double,
        conversion: String
    ): Boolean {
        var inputIsValid = true

        // Regex checks the text fields for for any letter in either lowercase, uppercase and if it contains spaces
        val textRegex = "^[a-zA-Z ]+$".toRegex()
        // Regex checks the text field for any numbers and will allow one decimal space if required
        val decimalRegex = "^\\d{0,9}\\.\\d{1,4}$".toRegex()
        // Regex checks the text field for any whole numbers
        val integerRegex = "^[0-9]*$".toRegex()

        // If statement used to check all input fields to ensure that none are empty
        if (unit == "" || value == "" || multiplier == 0.0 || conversion == "") {
            // Displays a message to the screen if at least on field is empty
            Toast.makeText(context, "All Data Must Be Filled", Toast.LENGTH_SHORT).show()
            inputIsValid = false
        }

        // If statement used to ensure that the value and conversion that has been entered is not the same
        else if (value == conversion || conversion == value) {
            Toast.makeText(context, "Value and Conversion Cannot be the Same", Toast.LENGTH_SHORT)
                .show()
            inputIsValid = false
        }

        // If statement used to check the if the unit only contains letters
        else if (!unit.matches(textRegex)) {
            // Displays a message to the screen if a non text character is entered for the unit
            Toast.makeText(context, "Unit can Only Contain Letters", Toast.LENGTH_SHORT).show()
            inputIsValid = false
        }

        // If statement used to check if the value only contains letters
        else if (!value.matches(textRegex)) {
            // Displays a message to the screen if a non text character is entered for the value
            Toast.makeText(context, "Value can Only Contain Letters", Toast.LENGTH_SHORT).show()
            inputIsValid = false
        }

        // If statement used to check if the conversion only contains letters
        else if (!conversion.matches(textRegex)) {
            // Displays a message to the screen if a non text character is entered for the conversion
            Toast.makeText(context, "Conversion can Only Contain Letters", Toast.LENGTH_SHORT)
                .show()
            inputIsValid = false
        }

        // Unable to get this validation working correctly

//        // If statement used to check if the multiplier only contains whole or decimal numbers
//        else if (!multiplier.toString().matches(integerRegex) || !multiplier.toString().matches(decimalRegex)) {
//            // Displays a message to the screen if a non integer or decimal character is entered
//            Toast.makeText(context, "Conversion can Only Contain Whole Numbers or Decimals", Toast.LENGTH_SHORT).show()
//            inputIsValid = false
//        }

        // Returns either true or false
        return inputIsValid
    }

    /**
     * Displays all the data that is currently being stored in the database.
     *
     * @param dataBase The instance of the database that will be used
     */
    private fun displayData(dataBase: UnitDataBase) {
        // This button performs the action of displaying the contents of the database
        displayButton.setOnClickListener() {
            var displayData = dataBase.displayData("")

            dataDisplayTextView.text = ""

            // If else statement used to check is displayData is empty
            if (displayData.isEmpty()) {
                // Displays a message to the screen telling the user that the database is currenlty empty
                Toast.makeText(context, "Database Currently Empty", Toast.LENGTH_SHORT).show()
            } else {
                // For statement used to go through every value in the database to then create string to be displayed to the screen
                for (i in 0 until displayData.size) {
                    dataDisplayTextView.append(
                        displayData[i].id.toString() + ". " + "Unit: " + displayData[i].category + " Value: " + displayData[i].convertFrom + " Multiplier: " +
                                displayData[i].multiplier + " Conversion: " + displayData[i].convertTo + "\n"
                    )
                }
            }
        }
    }

    /**
     * This currently does not work correctly as it does not find the id to be deleted.
     *
     * Deletes entities from the database with the use of entering the specific id.
     *
     * @param dataBase
     */
    private fun deleteData(dataBase: UnitDataBase) {
        var displayData = dataBase.displayData("")
        var id: Int = 0

        val dataBase = UnitDataBase(context!!)

        var conversionData = ConversionData()

        // This button performs the action of deleting a selected id from the database
        deleteButton.setOnClickListener() {
            // If statement used to check if has been any input entered
            if (deleteDatabaseValueNumberInput.text.toString().isNotEmpty()) {
                // Sets the id variable value to the number that has been entered by the user in the delete number field
                id = deleteDatabaseValueNumberInput.text.toString().toInt()

                // If statement used to check if the id entered is not a default value
                if (id > 80) {
                    // If statement used to check if the id entered is the same as the saved id in the conversionData
                    if (id == conversionData.id) {
                        // Calls the delete method in the database class with the id to be deleted passed in
                        dataBase.deleteData(id)
                    }

                    // Displays a message to the screen
                    Toast.makeText(context, "Successfully Deleted", Toast.LENGTH_SHORT).show()
                    // Displays the database to the screen
                    displayButton.performClick()
                    // Calls the clear text method to clear the text fields
                    clearText()

                    // Else if statement used to check if the id is a default value
                } else if (id > 0 || id <= 80) {
                    // Message displayed to screen stating that default values cannot be deleted from the database
                    Toast.makeText(context, "Cannot Delete Default Values", Toast.LENGTH_SHORT)
                        .show()
                }
                // Else if statement used to check is the database is currently empty
            } else if (displayData.isEmpty()) {
                // Message displayed to the screen telling the user that the database is currently empty
                Toast.makeText(context, "Database Currently Empty", Toast.LENGTH_SHORT).show()
            }
        }
    }
}