package uk.ac.stir.cs.unitconv

/**
 * This class holds all the required data for the data base,
 * it uses the data form the inputted values from the user and
 * adds it as anew entry into the UnitDataBase.
 *
 */
class ConversionData {
    var id: Int = 0
    var category: String = ""
    var convertFrom: String = ""
    var multiplier: Double = 0.0
    var convertTo: String = ""

    /**
     * The constructor is used to initialize the objects that will be
     * used for the database.
     */
    constructor(category: String, convertFrom: String, multiplier: Double, convertTo: String) {
        this.category = category
        this.convertFrom = convertFrom
        this.multiplier = multiplier
        this.convertTo = convertTo
    }

    // Runs the constructor
    constructor()
}